-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Vært: 127.0.0.1
-- Genereringstid: 27. 01 2019 kl. 23:51:31
-- Serverversion: 10.1.34-MariaDB
-- PHP-version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dimselab`
--
CREATE DATABASE IF NOT EXISTS `dimselab` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `dimselab`;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(10000) NOT NULL,
  `tray_number` char(4) NOT NULL,
  `barcode` varchar(100) NOT NULL,
  `on_loan` int(11) NOT NULL DEFAULT '0',
  `quantity` int(11) NOT NULL,
  `fk_category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Article_Category` (`fk_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `articles`
--

INSERT INTO `articles` (`id`, `name`, `tray_number`, `barcode`, `on_loan`, `quantity`, `fk_category_id`) VALUES
(1, 'Samsung Galaxy S8', '0007', 'ROD5.SGS8.0007', 0, 50, 1);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `article_projects`
--

DROP TABLE IF EXISTS `article_projects`;
CREATE TABLE IF NOT EXISTS `article_projects` (
  `fk_article_id` int(11) NOT NULL,
  `fk_project_id` int(11) NOT NULL,
  KEY `Article_Project` (`fk_article_id`),
  KEY `Project_Article` (`fk_project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Telefon');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` int(11) NOT NULL,
  `description` int(11) NOT NULL,
  `fk_user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `statistics`
--

DROP TABLE IF EXISTS `statistics`;
CREATE TABLE IF NOT EXISTS `statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_article_id` int(11) NOT NULL,
  `fk_user_id` int(11) NOT NULL,
  `fk_project_id` int(11) NOT NULL,
  `created` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `barcode` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Begrænsninger for dumpede tabeller
--

--
-- Begrænsninger for tabel `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `Article_Category` FOREIGN KEY (`FK_Category_ID`) REFERENCES `categories` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Begrænsninger for tabel `article_projects`
--
ALTER TABLE `article_projects`
  ADD CONSTRAINT `Article_Project` FOREIGN KEY (`FK_Article_ID`) REFERENCES `articles` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Project_Article` FOREIGN KEY (`FK_Project_ID`) REFERENCES `projects` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
